import { useState } from 'react'
import ThemeLogger from './components/ThemeLogger';
import Counter from './components/Counter';
import TextInput from './components/TextInput';

function App() {
  const [theme, setTheme] = useState('light');
  const [username, setUsername] = useState('');

  return (
    <div className ={`app ${theme}`}>
      <h1>React State app</h1>
      <ThemeLogger theme={theme} setTheme={setTheme} />

      <Counter />

      <TextInput username={username} setUsername={setUsername} />
      <p>Current username: {username}</p>
    </div>
  )
}

export default App
