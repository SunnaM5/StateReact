import React from 'react'

const ThemeLogger = () => {
  return (
    <div>ThemeLogger</div>
  )
}

export default ThemeLogger